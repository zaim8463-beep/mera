package com.hoda.scripts.automation;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class AutomationBootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context,Intent intent){if(intent!=null&&Intent.ACTION_BOOT_COMPLETED.equals(intent.getAction()))AutomationScheduler.scheduleAll(context);}
}
