package com.hoda.scripts.widget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import com.hoda.scripts.MainActivity;
import com.hoda.scripts.R;
import com.hoda.scripts.data.ShortcutStore;
import com.hoda.scripts.model.Shortcut;
import java.util.List;

/** Small home-screen launcher for the four most recently updated user shortcuts. */
public final class HodaWidgetProvider extends AppWidgetProvider {
    public static final String ACTION_RUN_SHORTCUT = "com.hoda.scripts.widget.RUN_SHORTCUT";
    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        ShortcutStore store = new ShortcutStore(context);
        List<Shortcut> shortcuts = store.all();
        for (int widgetId : ids) {
            RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.hoda_widget);
            views.removeAllViews(R.id.widget_shortcuts);
            int count = Math.min(4, shortcuts.size());
            for (int i = 0; i < count; i++) {
                Shortcut shortcut = shortcuts.get(i);
                RemoteViews item = new RemoteViews(context.getPackageName(), R.layout.hoda_widget_item);
                item.setTextViewText(R.id.widget_item_title, shortcut.icon + "  " + shortcut.name);
                Intent run = new Intent(context, MainActivity.class);
                run.setAction(ACTION_RUN_SHORTCUT);
                run.putExtra("hoda_shortcut_id", shortcut.id);
                run.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                PendingIntent pending = PendingIntent.getActivity(context, (int)(shortcut.id & 0x7fffffff), run,
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                item.setOnClickPendingIntent(R.id.widget_item_title, pending);
                views.addView(R.id.widget_shortcuts, item);
            }
            if (count == 0) views.setTextViewText(R.id.widget_empty, "Create shortcuts in Hoda Scripts");
            else views.setViewVisibility(R.id.widget_empty, android.view.View.GONE);
            Intent open = new Intent(context, MainActivity.class);
            PendingIntent openPending = PendingIntent.getActivity(context, 99001, open,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            views.setOnClickPendingIntent(R.id.widget_header, openPending);
            manager.updateAppWidget(widgetId, views);
        }
    }
    public static void refresh(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, HodaWidgetProvider.class));
        if (ids.length > 0) new HodaWidgetProvider().onUpdate(context, manager, ids);
    }
}
