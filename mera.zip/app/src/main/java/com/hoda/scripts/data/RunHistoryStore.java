package com.hoda.scripts.data;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;

/** Small on-device execution history. Keeps only recent metadata, never shortcut input/output values. */
public final class RunHistoryStore {
    private static final String PREFS = "hoda_run_history";
    private static final String KEY = "entries";
    private static final int LIMIT = 100;
    private RunHistoryStore() {}

    public static synchronized void add(Context context, String name, boolean success, String detail) {
        SharedPreferences prefs = context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        JSONArray old;
        try { old = new JSONArray(prefs.getString(KEY, "[]")); } catch (Exception e) { old = new JSONArray(); }
        JSONArray next = new JSONArray();
        try {
            JSONObject item = new JSONObject();
            item.put("name", name == null ? "Hoda Scripts" : name);
            item.put("success", success);
            item.put("detail", detail == null ? "" : detail);
            item.put("time", System.currentTimeMillis());
            next.put(item);
            for (int i = 0; i < old.length() && next.length() < LIMIT; i++) {
                JSONObject previous = old.optJSONObject(i);
                if (previous != null) next.put(previous);
            }
        } catch (Exception ignored) { return; }
        prefs.edit().putString(KEY, next.toString()).apply();
    }

    public static synchronized JSONArray get(Context context) {
        try { return new JSONArray(context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]")); }
        catch (Exception e) { return new JSONArray(); }
    }

    public static synchronized void clear(Context context) {
        context.getApplicationContext().getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY).apply();
    }
}
