package com.hoda.scripts.automation;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import org.json.JSONObject;
import java.util.Calendar;

/** Uses inexact-while-idle alarms for daily time rules; exact-alarm privilege is not required. */
public final class AutomationScheduler {
    private AutomationScheduler(){}
    public static void scheduleAll(Context c){for(JSONObject r:AutomationRuleStore.all(c))schedule(c,r);}
    public static void schedule(Context c,JSONObject rule){
        if(!rule.optBoolean("enabled",true)||!"daily_time".equals(rule.optString("trigger")))return;
        int hour=rule.optInt("hour",9),minute=rule.optInt("minute",0);
        Calendar next=Calendar.getInstance();next.set(Calendar.HOUR_OF_DAY,hour);next.set(Calendar.MINUTE,minute);next.set(Calendar.SECOND,0);next.set(Calendar.MILLISECOND,0);if(next.getTimeInMillis()<=System.currentTimeMillis())next.add(Calendar.DAY_OF_YEAR,1);
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);if(am==null)return;
        PendingIntent pi=pending(c,rule.optString("id"));
        if(Build.VERSION.SDK_INT>=23)am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,next.getTimeInMillis(),pi);else am.set(AlarmManager.RTC_WAKEUP,next.getTimeInMillis(),pi);
    }
    public static void cancel(Context c,String id){AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);if(am!=null)am.cancel(pending(c,id));}
    private static PendingIntent pending(Context c,String id){Intent i=new Intent(c,AutomationAlarmReceiver.class);i.setAction("com.hoda.scripts.AUTOMATION_ALARM."+id);i.putExtra(AutomationAlarmReceiver.EXTRA_RULE_ID,id);return PendingIntent.getBroadcast(c,id.hashCode(),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
}
