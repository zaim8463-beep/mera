package com.hoda.scripts;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.graphics.*;
import android.graphics.drawable.ColorDrawable;
import android.view.*;
import android.widget.Toast;

/** Full-screen, temporary region selector. Returns screen coordinates. */
public final class RegionSelectorActivity extends Activity {
    private SelectorView view;
    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(Color.TRANSPARENT);getWindow().setNavigationBarColor(Color.TRANSPARENT);getWindow().setFlags(WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);view=new SelectorView();setContentView(view);}
    private final class SelectorView extends View {
        Paint fill=new Paint(1),stroke=new Paint(1),text=new Paint(1);float sx,sy,ex,ey;boolean dragging;
        SelectorView(){super(RegionSelectorActivity.this);setLayerType(View.LAYER_TYPE_SOFTWARE,null);fill.setColor(0x553A2BE8);stroke.setColor(0xFF7357E8);stroke.setStyle(Paint.Style.STROKE);stroke.setStrokeWidth(4);text.setColor(Color.WHITE);text.setTextSize(38);text.setTypeface(Typeface.DEFAULT_BOLD);setBackgroundColor(0x22000000);}
        protected void onDraw(Canvas c){super.onDraw(c);if(!dragging&&sx==0&&sy==0)return;float l=Math.min(sx,ex),t=Math.min(sy,ey),r=Math.max(sx,ex),b=Math.max(sy,ey);c.drawRect(l,t,r,b,fill);c.drawRect(l,t,r,b,stroke);String s=Math.round(r-l)+" × "+Math.round(b-t);c.drawText(s,l+12,Math.max(45,t+42),text);}
        public boolean onTouchEvent(android.view.MotionEvent e){switch(e.getActionMasked()){case MotionEvent.ACTION_DOWN:sx=ex=e.getRawX();sy=ey=e.getRawY();dragging=true;invalidate();return true;case MotionEvent.ACTION_MOVE:ex=e.getRawX();ey=e.getRawY();invalidate();return true;case MotionEvent.ACTION_UP:ex=e.getRawX();ey=e.getRawY();dragging=false;invalidate();int l=(int)Math.min(sx,ex),t=(int)Math.min(sy,ey),r=(int)Math.max(sx,ex),b=(int)Math.max(sy,ey);if(r-l<20||b-t<20){Toast.makeText(RegionSelectorActivity.this,"حدد مساحة أكبر",Toast.LENGTH_SHORT).show();return true;}Intent data=new Intent();data.putExtra("x",l);data.putExtra("y",t);data.putExtra("width",r-l);data.putExtra("height",b-t);setResult(RESULT_OK,data);finish();return true;}return true;}
    }
}
