package com.hoda.scripts.plugins;

import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/** Explicit registry for app-owned extensions. No arbitrary class loading or silent third-party code execution. */
public final class ShortcutPluginRegistry {
    private static final Map<String, ShortcutActionPlugin> PLUGINS = new LinkedHashMap<>();
    private ShortcutPluginRegistry() {}
    public static synchronized boolean register(ShortcutActionPlugin plugin) {
        if (plugin == null || plugin.id() == null || plugin.id().trim().isEmpty()) return false;
        if (PLUGINS.containsKey(plugin.id())) return false;
        PLUGINS.put(plugin.id(), plugin);
        return true;
    }
    public static synchronized ShortcutActionPlugin get(String id) { return PLUGINS.get(id); }
    public static synchronized Map<String, ShortcutActionPlugin> all() {
        return Collections.unmodifiableMap(new LinkedHashMap<>(PLUGINS));
    }
}
